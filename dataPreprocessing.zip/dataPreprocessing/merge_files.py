import pandas as pd
import glob
import os
import config

path1 = r'E:\final_data'
all_files = glob.glob(os.path.join(path1, "*.csv"))

al_df = []
for f in all_files:
    dataframe = pd.read_csv(f)
    al_df.append(dataframe)

final_csv = pd.concat(al_df, ignore_index=False, sort=False)
# combined_csv['class'] = 1
print(final_csv)

#export to csv
final_csv.to_csv(config.DESTINATION_DIR_FINAL, index=False, encoding='utf-8-sig')
print(final_csv.shape)
# print(len("column",final_csv.column))
# print(final_csv.csv)