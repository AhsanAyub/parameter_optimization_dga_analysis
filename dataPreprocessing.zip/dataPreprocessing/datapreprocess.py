import pandas as pd
import glob
import os

# path = r'E:\Important\data'
# all_files = glob.glob(os.path.join(path, "*.csv"))


# lod = 0
# all_df = []
# all_smalldf = []

# for f in all_files:
#     lod = lod + 1
#     print("Loading", lod )
#     dataframe = pd.read_csv(f, sep=',',skiprows=2, header = None)
#
#     print("column number",len(dataframe.columns))
#     if((len(dataframe.columns)) == 5):
#         df = dataframe.iloc[:, [0,4]]
#         if(len(df.index)>500):
#               all_df.append((df[1:500]))

#         else:
#             all_df.append(df[1:])
#     else:
#         df = dataframe.iloc[:,[0,2]]
#         print(df.head())
#         if (len(df.index) > 500):
#             all_smalldf.append(df[1:500])
#         else:
#             all_smalldf.append(df[1:])
#
# #     check_for_nan = df['e'].isnull().values.any()
# #     print(check_for_nan)
# #     df['file'] = f.split('/')[-1]
# #     if(check_for_nan == False):
# #         df1 = df[['a', 'e']]
# #         print("ok")
# #         if(len(df1.index)>500):
# #             all_df.append(df1[:500])
# #             cnt += 1
# #         else:
# #             all_df.append(df1)
# #             cnt2 = cnt2 + 1
# #     else:
# #         if (len(df.index) > 500):
# #             df = df[['a', 'c']]
# #             all_df.append(df[:500])
# #             cnt += 1
# #         else:
# #             df = df[['a', 'c']]
# #             all_df.append(df)
# #             cnt2 = cnt2 + 1


# print(all_smalldf)
# merged_df = pd.concat(all_df, ignore_index=False, sort=True)
# merged_df['class'] = 1
#
# merged_df_extra = pd.concat(all_smalldf, ignore_index=False, sort=True)
# merged_df_extra['class'] = 1
#
# # print(len(merged_df.index))
# # print(merged_df)
# # print(len(merged_df.index))
# # # print("over 800",cnt)
# # # print("under 800",cnt2)
# merged_df.to_csv( "combined2_csv.csv", index=False, encoding='utf-8-sig', header=False )
# merged_df_extra.to_csv( "combined3_csv.csv", index=False, encoding='utf-8-sig', header=False )
# # print(merged_df_extra.index)

# path1 = r'C:\Users\Asus\PycharmProjects\dataPreprocessing'
# all_files = glob.glob(os.path.join(path1, "*.csv"))
#
# al_df = []
# for f in all_files:
#     dataframe = pd.read_csv(f, sep=',',skiprows=2, header = None)
#     al_df.append(dataframe)
#
# final_csv = pd.concat(al_df, ignore_index=False, sort=True)
# # combined_csv['class'] = 1
#
# #export to csv
# final_csv.to_csv( "final_csv.csv", index=False, encoding='utf-8-sig')
# print(final_csv.shape)
# # print(len("column",final_csv.column))
# # print(final_csv.csv)
import config

"""
    for good dataset
"""

dataframe = pd.read_csv(r'E:\Important\majestic\majestic_million.csv', sep=',',skiprows=2, header = None)

print("column number",len(dataframe.columns))

my_dict = {"URL": [], "Family": [], "Class": []}
df = dataframe.iloc[:, [2]]
df = df[1:40000]

df["Family"] = "Good"
df["Class"] = 0
df.columns.values[0] = "URL"
# df.to_csv('updated_majestic.csv', index=False)
df.to_csv(config.DESTINATION_DIR_GOOD, mode='w', index=False, sep=",")
print(df.head())
print(df.shape)

