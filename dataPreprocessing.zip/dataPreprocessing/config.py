SOURCE_DIR = "E:\Important\data"
DESTINATION_DIR = "E:\\final_data\\res.csv"
DESTINATION_DIR_GOOD = "E:\\final_data\\res1.csv"
DESTINATION_DIR_FINAL = "E:\\final_data\\final__csv.csv"
LIMIT = 600

