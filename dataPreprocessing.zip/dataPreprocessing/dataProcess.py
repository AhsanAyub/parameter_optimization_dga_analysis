import pandas as pd
import glob
import os
from collections import defaultdict


path1 = r'C:\Users\Asus\PycharmProjects\dataPreprocessing'
all_files = glob.glob(os.path.join(path1, "*.csv"))

al_df = []
for f in all_files:
    dataframe = pd.read_csv(f, sep=',',skiprows=2, header = None)
    al_df.append(dataframe)

final_csv = pd.concat(al_df, ignore_index=False, sort=True)
# combined_csv['class'] = 1

#export to csv
final_csv.to_csv("final_csv.csv", index=False, encoding='utf-8-sig')
print(final_csv.shape)
# print(len("column",final_csv.column))
# print(final_csv.csv)


"""
    for good dataset
"""

# dataframe = pd.read_csv(r'E:\Important\majestic\majestic_million.csv', sep=',',skiprows=2, header = None)
#
# print("column number",len(dataframe.columns))
# df = dataframe.iloc[:, [2,3]]
# df = df[1:50000]
# df["class"] = 0
# df.to_csv('updated_majestic.csv', index=False)
# print(df.shape)

