import pandas as pd
import glob
import os
import config


class DataProcess:
	def __init__(self):
		self.source = config.SOURCE_DIR
		self.destination = config.DESTINATION_DIR
		self.my_dict = {"URL": [], "Family": [], "Class": []}
		self.limit = config.LIMIT
		self.df_result = None

	def process_data(self):
		all_files = glob.glob(os.path.join(self.source, "*.csv"))
		for f in all_files:
			try:
				data_frame = pd.read_csv(f, sep=',')

				print("column number", len(data_frame))
				if (len(data_frame.columns)) == 5:
					df = data_frame.iloc[:, 0]
					df1 = data_frame.iloc[:, 4]
					if len(df.index) > self.limit:
						for i in range(1, self.limit):
							self.my_dict["URL"].append(df[i])
							self.my_dict["Family"].append(df1[i])
							self.my_dict["Class"].append(1)
					else:
						for i in range(1, len(df)):
							self.my_dict["URL"].append(df[i])
							self.my_dict["Family"].append(df1[i])
							self.my_dict["Class"].append(1)
				else:
					df = data_frame.iloc[:, 0]
					df1 = data_frame.iloc[:, 2]
					if len(df.index) > self.limit:
						for i in range(1, self.limit):
							self.my_dict["URL"].append(df[i])
							self.my_dict["Family"].append(df1[i])
							self.my_dict["Class"].append(1)
					else:
						for i in range(1, len(df)):
							self.my_dict["URL"].append(df[i])
							self.my_dict["Family"].append(df[i])
							self.my_dict["Class"].append(1)
			except ValueError as e:
				print("Error is : ", e)

		self.df_result = self.dict_to_df()
		print(len(self.df_result))
		print(self.save_result())

	def dict_to_df(self):
		return pd.DataFrame(self.my_dict)

	def save_result(self):
		if self.df_result.to_csv(self.destination, mode='w', index=False, sep=","):
			return True
		else:
			return False


if __name__ == '__main__':
	data_process = DataProcess()
	data_process.process_data()
